# Project Name:  Lesson 3 Version Control

## Course Title:
LIS 2360:  Web Application Development

## Assignment Date:  
(February 3, 2017)

## Student Name:  
(John Forrester)

## Project Description:
(In this assignment, we learned about GIT and Version control systems. Through the use of github, we managed to backup and view all files and modifications with our cloud 9 workspace. This would ensure that all of our data is safe and all previous versions can be retrieved.)

## Lessons Learned in the Assignment:
1. (I learned about the importance of GIT for IT majors. The service provided by GIT allows users to access their files remotely and locally. This allows for excellent backup while doing work individually and amongst peers.)
2. (I learned how to use/link my github account to other services such as cloud 9. This allowed for all of my file modifications and recalls to be documented and preserved incase I needed to go back to a previous version.)
3. (I learned how to use GIT commands such as GIT commit and GIT push/pull. These commands and many more will prove progressively useful the more I use GIT and become familiar with it.)
